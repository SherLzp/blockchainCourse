<script>
import Web3 from "web3";
import Crowdfunding from "../build/contracts/Crowdfunding.json";

window.ethereum.enable();
const web3 = new Web3(window.ethereum);
//const web3 = new Web3.providers.HttpProvider("http://127.0.0.1:7545");
const contract = new web3.eth.Contract(
  Crowdfunding.abi,
  "0xaf91eD0269f3503ae070059550B0B223B1114903"
);

export default {
  web3,
  contract,
};
</script>