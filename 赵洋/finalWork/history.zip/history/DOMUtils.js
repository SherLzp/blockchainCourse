'use strict';
require('./warnAboutDeprecatedCJSRequire.js')('DOMUtils');
module.exports = require('./index.js').DOMUtils;
